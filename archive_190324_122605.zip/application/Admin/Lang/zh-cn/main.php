<?php
return array(
	'SYSTEM_INFORMATIONS' => '系统信息',
	'SYSTEM_NOTIFICATIONS' => '系统通知',
	'INITIATE_TEAM' => '发起团队',
	'CONTRIBUTORS' => '贡献者',
	'CONTACT_EMAIL' => '联系邮箱',
	'TEAM_MEMBERS' => '团队成员',
	'OPERATING_SYSTEM' => '操作系统',
	'OPERATING_ENVIRONMENT' =>'运行环境',
	'PHP_RUN_MODE' => 'PHP运行方式',
	'PHP_VERSION' => 'PHP版本',
	'MYSQL_VERSION' => 'MYSQL版本',
	'PROGRAM_VERSION' => '程序版本',
	'UPLOAD_MAX_FILESIZE' => '上传附件限制',
	'MAX_EXECUTION_TIME' =>'执行时间限制',
	'DISK_FREE_SPACE' => '剩余空间',
	'SECONDS' => '秒',
	'UNKNOWN' => '未知',
	'NO_NOTICE' => '没有通知啦'
);