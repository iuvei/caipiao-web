<?php
return array(
    "DEFAULT" => 'Default',
    "QINIU" => "Qiniu",
    "DOMAIN" => 'Domain',
    "BUCKET" => 'Bucket',
    "GET_ACCESS_KEY" => 'Get AccessKey',
    "QINIU_PROMOTION_CODE" => 'Promotion Code',
    "GET_IT_NOW" => 'Get it Now!'
);