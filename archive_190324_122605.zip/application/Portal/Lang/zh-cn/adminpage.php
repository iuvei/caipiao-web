<?php
return array(
    "TITLE" => '标题',
    "AUTHOR" => '作者',
    "POST_DATE" => '发布时间',
    "KEYWORD" => '关键字',
    "PLEASE_ENTER_KEYWORD" => '请输入关键字...',
    "SEARCH" => '搜索'
);