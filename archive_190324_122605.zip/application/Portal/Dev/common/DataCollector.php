<?php
/**
 * 数据汇总
 */

Class DataCollector {

    /**
     * 获取数据
     */
    public static function get($key) {
        return RedisCache::get(self::retreiveKey($key));
    }

    /**
     * 设置数据，保留4小时
     */
    public static function set($key, $content, $expire = 3600 * 4) {
        return RedisCache::set(self::retreiveKey($key), $content, $expire);
    }

    private static function retreiveKey($key) {
        return str_replace(DEV_DATA_PATH . 'tmp/', 'data_collector:', $key);
    }
}
