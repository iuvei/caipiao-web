<?php

namespace Common\Model;

use Common\Model\CommonModel;

class RuleModel extends CommonModel {
    
}
