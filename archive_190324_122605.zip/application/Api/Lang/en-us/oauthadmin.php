<?php
return array(
    "QQ_CONNECT" => 'QQ',
    "WEIBO_CONNECT" => 'Sina Weibo',
    "CLICK_HERE" => 'Click Here',
    "GET_QQ_APPKEY_AND_APPSECRET" => "Get QQ Connect's AppKey and AppSecret",
    "GET_WEIBO_APPKEY_AND_APPSECRET" => "Get Weibo Connect's AppKey and AppSecret",
    "CALLBACK_URL"  => 'Callback Url',
    "CANCEL_CALLBACK_URL" => 'Cancel Callback Url'
);