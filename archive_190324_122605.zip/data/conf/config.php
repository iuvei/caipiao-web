<?php
// 引入库
include_once  __DIR__ . '/../../application/Portal/Dev/common/common.php';

// 业务配置
define('AGENT_BIG_AMOUNT', 999999999);

return array (
  'SP_SITE_ADMIN_URL_PASSWORD' => '293bb4bc69d5a8622e56f3a8ed1eb7a7',
  'SP_DEFAULT_THEME'           => 'bootstrap',
  'DEFAULT_THEME'              => 'bootstrap',
  'SP_ADMIN_STYLE'             => 'flat',
  'URL_MODEL'                  => '3',
  'URL_HTML_SUFFIX'            => '',
  'COMMENT_NEED_CHECK'         => 0,
  'COMMENT_TIME_INTERVAL'      => 60,
  'MOBILE_TPL_ENABLED'         => 1,
  'HTML_CACHE_ON'              => false,
  'SP_MAIL_ADDRESS'            => '',
  'SP_MAIL_SENDER'             => '必发彩票',
  'SP_MAIL_SMTP'               => 'smtp.163.com',
  'SP_MAIL_SECURE'             => '',
  'SP_MAIL_SMTP_PORT'          => '',
  'SP_MAIL_LOGINNAME'          => '',
  'SP_MAIL_PASSWORD'           => 'zmm123456',
);