<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => '127.0.0.1',
    'DB_NAME' => 'qxc_sdc',
    'DB_USER' => 'root',
    'DB_PWD' => '!2i#sn7j7',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'jz_',
    //密钥
    "AUTHCODE" => 't9efJStFdrGa6pRck5',
    //cookies
    "COOKIE_PREFIX" => 'VPFv3w_',
);
