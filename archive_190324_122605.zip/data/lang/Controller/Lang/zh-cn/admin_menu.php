<?php
return array (
  'CONTROLLER_ADMINORDER_INDEX' => 'Portal',
);