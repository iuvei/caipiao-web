<?php
return array (
  'PROTAL_ADMINORDER_ADDPLAN' => '添加计划',
);