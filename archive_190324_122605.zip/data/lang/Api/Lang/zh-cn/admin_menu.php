<?php
return array (
  'API_OAUTHADMIN_SETTING_POST' => '提交设置',
  'API_OAUTHADMIN_SETTING' => '第三方登陆',
);