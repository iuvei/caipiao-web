<?php if (!defined('THINK_PATH')) exit();?>
<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>代理报告</title>
    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

    <link href="/public/simpleboot/themes/flat/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
        form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
        .table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
        .table-list{margin-bottom: 0px;}
    </style>
    <!--[if IE 7]>
    <link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
    <![endif]-->
    <script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "/",
        WEB_ROOT: "/",
        JS_ROOT: "public/js/",
        APP:'Admin'/*当前应用名*/
    };
    </script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(function(){
            $("[data-toggle='tooltip']").tooltip();
        });
    </script>
<style>
#think_page_trace_open{
    display: none !important;
    z-index:9999;
}
.wrap {
    width: 95%;
    max-width: 800px;
    margin: 0 auto;
    color: #333;
    background: #fafafa;
    z-index: 1;
    padding: 5px;
}
.agent-reporter-wrapper {
    font-size: 12px;
    overflow-y: scroll;
}

li {
    list-style: none;
}
</style>
</head>
<body>
    <div class="wrap">
        <h4>代理报告</h4>
        <div class="agent-reporter-wrapper"></div>

    </div>
    <script src="/public/js/common.js"></script>
    <script>
        // 代理行为报告信息
        var get_agent_new_event = function() {
            $.get('/index.php?s=/admin/public/getAgentNewEvent', function(d) {
                $('.agent-reporter-wrapper').prepend(d);
            });
        };
        setInterval(get_agent_new_event, 3000);
    </script>
</body>
</html>