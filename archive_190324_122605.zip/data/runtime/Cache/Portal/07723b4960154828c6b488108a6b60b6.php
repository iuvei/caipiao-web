<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<link href="/public/simpleboot/themes/<?php echo C('SP_ADMIN_STYLE');?>/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
	<script type="text/javascript">
	//全局变量
	var GV = {
	    ROOT: "/",
	    WEB_ROOT: "/",
	    JS_ROOT: "public/js/",
	    APP:'<?php echo (MODULE_NAME); ?>'/*当前应用名*/
	};
	</script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
    	$(function(){
    		$("[data-toggle='tooltip']").tooltip();
    	});
    </script>
<?php if(APP_DEBUG): ?><style>
		#think_page_trace_open{
			z-index:9999;
		}
	</style><?php endif; ?>
</head>
<body>
    <div class="wrap">
        <ul class="nav nav-tabs">
            <li class="active"><a href="<?php echo U('Portal/AdminUser/user_level');?>">代理等级</a></li>
            <li ><a href="<?php echo U('Portal/AdminUser/add_user_level');?>" >添加等级</a></li>
        </ul>
<!--         <form class="well form-search" method="post" action="<?php echo U('Portal/AdminUser/index');?>">
            用户名:
            <input type="text" name="user_login" style="width: 200px;" value="<?php echo I('request.user_login/s','');?>" placeholder="请输入用户名">
                        邮箱:
                        <input type="text" name="user_email" style="width: 100px;" value="<?php echo I('request.user_email/s','');?>" placeholder="请输入<?php echo L('EMAIL');?>">
            <input type="submit" class="btn btn-primary" value="搜索" />
            
        </form> -->
        <!-- <form class="well form-search" method="post" action="<?php echo U('AdminUser/index');?>">
            用户ID： 
            <input type="text" name="uid" style="width: 100px;" value="<?php echo I('request.uid');?>" placeholder="请输入用户ID">
            关键字： 
            <input type="text" name="keyword" style="width: 200px;" value="<?php echo I('request.keyword');?>" placeholder="用户名/昵称/邮箱">
            <input type="submit" class="btn btn-primary" value="搜索" />
            <input type="reset" class="btn btn-danger" value="清空" />
            
        </form> -->
        <form method="post" class="js-ajax-form">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th align="center">ID</th>
                        <th>等级</th>
                        
                        <!-- <th>头像</th> -->
                        <th style="vertical-align:middle; text-align:center;">名称</th>
                        <th style="width:200px;" align="center">操作</th>
                    </tr>
                </thead>
                <tbody>

                    <?php if(is_array($list)): foreach($list as $key=>$vo): ?><tr>
                        <td align="center"><?php echo ($vo["id"]); ?></td>
                        <td ><?php echo ($vo["level"]); ?></td>
                        <td style="vertical-align:middle; text-align:center;"><?php echo ($vo["title"]); ?></td>
                        <td align="center">
                            <a href='<?php echo U("AdminUser/level_edit",array("id"=>$vo["id"]));?>'>修改</a> |
                            <a class="js-ajax-delete" href="<?php echo U('adminUser/level_delete',array('id'=>$vo['id']));?>">删除</a> |
                           <!--  <?php if(($vo["id"]) != "1"): ?><a href="<?php echo U('AdminUser/ban',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="您确定要拉黑此用户吗？">拉黑</a>|
                                <a href="<?php echo U('AdminUser/edit',array('id'=>$vo['id']));?>" class="iframe" id="iframe" >编辑</a>|
                                <a href="<?php echo U('AdminUser/cancelban',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="您确定要启用此用户吗？">启用</a>
                            <?php else: ?>
                                <a style="color: #ccc;">拉黑</a>|
                                <a style="color: #ccc;">启用</a><?php endif; ?>
                             <?php if($vo['is_grade'] == 1): ?><a href='<?php echo U("AdminUser/relationship",array("id"=>$vo["id"]));?>'>子账号</a> |<?php endif; ?>
                                <a href='<?php echo U("AdminUser/edit",array("id"=>$vo["id"]));?>'><?php echo L('EDIT');?></a> |
                                <a class="js-ajax-delete" href="<?php echo U('adminUser/delete',array('id'=>$vo['id']));?>"><?php echo L('DELETE');?></a> |
                                <?php if($vo['user_status'] == 0): ?><a href="<?php echo U('adminUser/disable',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="确认封号">封号</a>
                                    <?php else: ?>
                                    <a href="<?php echo U('adminUser/unDisable',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="确认解封">解封</a><?php endif; ?>
                            <?php if($vo['user_status'] == 0): ?>| <a href="<?php echo U('adminUser/Limit',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="确认激活">限制登录</a>
                                 <?php else: ?>
                                 <a href="<?php echo U('adminUser/unLimit',array('id'=>$vo['id']));?>" class="js-ajax-dialog-btn" data-msg="确认解封">解除限制</a><?php endif; ?>
                                <a href='<?php echo U("AdminUser/Recharge",array("id"=>$vo["id"]));?>' target="_blank">充值</a> -->
                        </td>
                    </tr><?php endforeach; endif; ?>
                </tbody>
            </table>
            <div class="pagination"><?php echo ($page); ?></div>
        </form>
    </div>
    <script src="/public/js/common.js"></script>
</body>
</html>