<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0062)http://fw5.b789b.com/index.php?action=settings&action=editpass -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <title></title>
    <script type="text/javascript">var IMGDIR = './images/'; var attackevasive = '0';</script>
    
</head>
    <body leftmargin="10" topmargin="10">
        <div id="append_parent"></div>
        <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td>

                        <style media="print">
                            .Noprint {
                                display: none;
                            }
                        </style>
                        <form method="post" action="/ChangePassword/EditPassword" data-bind="submit:sub">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
                                <tbody>
                                    <tr class="header">
                                    <td colspan="2">帐户修改密码
                                      
                                         </td>
                                    </tr>
                                    <tr id="isShowCompany">
                                        <td class="altbg1"><span>是否修改高级密码:</span></td>
                                        <td align="right" class="altbg2">
                                            <input type="checkbox" name="isAdvancedPassword" id="isAdvancedPassword" size="25" tabindex="2" />
                                            <span style="color:red">(提示：如果修改高级密码，请勾选；默认是修改账号密码)</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="altbg1">旧密码:</td>
                                        <td align="right" class="altbg2">
                                            <input type="password" name="oldpassword" id="oldpassword" size="25" tabindex="2" />
                                            <font style="font-size:14px;color:#ff0000"> (密码的长度必须在8-15位之间,并且包含字母和数字)</font>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="altbg1">新密码:</td>
                                        <td align="right" class="altbg2">
                                            <input type="password" name="newpassword" id="newpassword" size="25" tabindex="2" />
                                            <font style="font-size:14px;color:#ff0000"> (密码的长度必须在8-15位之间,并且包含字母和数字)</font>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="altbg1">确认新密码:</td>
                                        <td>
                                            <input type="password" name="newpassword2" id="newpassword2" size="25" tabindex="3" />
                                            <font style="font-size:14px;color:#ff0000"> (确认密码与密码必须保持一致)</font>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>    <br />
                            <center>
                                <button type="submit" class="button" name="editsubmit" id="editsubmit" value="true">提 交</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                
                            </center>
                        </form>
                        <script>
                            setTimeout("document.form1.oldpassword.focus(); ", 200);
                        </script>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>