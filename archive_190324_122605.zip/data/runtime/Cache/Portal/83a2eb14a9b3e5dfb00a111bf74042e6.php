<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<link href="/public/simpleboot/themes/<?php echo C('SP_ADMIN_STYLE');?>/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
	<script type="text/javascript">
	//全局变量
	var GV = {
	    ROOT: "/",
	    WEB_ROOT: "/",
	    JS_ROOT: "public/js/",
	    APP:'<?php echo (MODULE_NAME); ?>'/*当前应用名*/
	};
	</script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
    	$(function(){
    		$("[data-toggle='tooltip']").tooltip();
    	});
    </script>
<?php if(APP_DEBUG): ?><style>
		#think_page_trace_open{
			z-index:9999;
		}
	</style><?php endif; ?>
</head>
<body>
    <div class="wrap js-check-wrap">
        <form class="form-horizontal" action="<?php echo U('Portal/AdminOrder/xgzd2_post');?>" method="post">
            <fieldset>
                <div class="control-group" >
                    <label class="control-label">注单信息ID</label>
                    <div class="controls" >
                        <?php echo ($bet["betinfoid"]); ?>
                    </div>
                </div>
                <div class="control-group" >
                    <label class="control-label">下注信息</label>
                    <div class="controls" >
                        <?php echo ($bet["bz"]); ?>，共<?php echo ($bet["count"]); ?>个号
                    </div>
                </div>
                <div class="control-group" >
                    <label class="control-label">仟/佰/拾/个</label>
                    <div class="controls">
                        <input type="text" id="betnumber1" class="betnumber-input" name="betnumber1" value="<?php echo ($bz_info['betnumber1']); ?>" required style="width: 100px">
                        <input type="text" id="betnumber2" class="betnumber-input" name="betnumber2" value="<?php echo ($bz_info['betnumber2']); ?>" required style="width: 100px">
                        <input type="text" id="betnumber3" class="betnumber-input" name="betnumber3" value="<?php echo ($bz_info['betnumber3']); ?>" required style="width: 100px">
                        <input type="text" id="betnumber4" class="betnumber-input" name="betnumber4" value="<?php echo ($bz_info['betnumber4']); ?>" required style="width: 100px">
                    </div>
                </div>
                <div class="control-group" >
                    <label class="control-label">号码列表</label>
                    <div class="controls">
                        <pre id="generated_numbers" style="max-width: 600px;"></pre>
                    </div>
                </div>
            </fieldset>
            <div class="form-actions">
                <input type="hidden" name="bet_id" value="<?php echo ($bet["id"]); ?>"/>
                <input type="hidden" name="uid" value="<?php echo ($uid); ?>"/>
                <input type="hidden" id="submit_numbers" name="numbers" value=""/>
                <input type="submit" class="btn btn-primary">
                <a class="btn" href="javascript:history.back(-1);"><?php echo L('BACK');?></a>
            </div>
        </form>
    </div>
    <script src="/public/js/common.js"></script>
    <script>
        $(function() {
            // 如果是随机号，则仅读
            $('.betnumber-input[value="X"]').prop('readonly', true);
            // 生成结果
            generate_numbers();
            // 修改内容时重新生成结果
            $('.betnumber-input').on('keyup', function() {
                generate_numbers();
            });
        });

        function generate_numbers() {
            var number_list = [];
            var betnumber1 = unique_string($('#betnumber1').val());
            var betnumber2 = unique_string($('#betnumber2').val());
            var betnumber3 = unique_string($('#betnumber3').val());
            var betnumber4 = unique_string($('#betnumber4').val());
            var arr = [
                betnumber1.split(''),
                betnumber2.split(''),
                betnumber3.split(''),
                betnumber4.split(''),
            ];
            var results = [];
            var result = [];
            number_list = do_exchange(arr, 0);
            function do_exchange(arr, index) {
                for (var i = 0; i<arr[index].length; i++) {
                    result[index] = arr[index][i];
                    if (index != arr.length - 1) {
                        do_exchange(arr, index + 1)
                    } else {
                        results.push(result.join(''))
                    }
                }
                return results;
            }
            // console.log(number_list);
            var numbers = number_list.join(',');
            $('#generated_numbers').html(numbers);
            $('#submit_numbers').val(numbers);
        }

        function unique_string(str) {
          // 存放结果
          var res = "";
          // 遍历字符串元素
          for (var i in str) {
            // 如果结果不存在该元素则保存
            if (res.indexOf(str.charAt(i)) == -1) {
               res += str.charAt(i);
            }
          }
          // 返回去重后的字符串
          return res;
        }

    </script>
</body>
</html>