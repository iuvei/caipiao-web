<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<link href="/public/simpleboot/themes/<?php echo C('SP_ADMIN_STYLE');?>/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
	<script type="text/javascript">
	//全局变量
	var GV = {
	    ROOT: "/",
	    WEB_ROOT: "/",
	    JS_ROOT: "public/js/",
	    APP:'<?php echo (MODULE_NAME); ?>'/*当前应用名*/
	};
	</script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
    	$(function(){
    		$("[data-toggle='tooltip']").tooltip();
    	});
    </script>
<?php if(APP_DEBUG): ?><style>
		#think_page_trace_open{
			z-index:9999;
		}
	</style><?php endif; ?>
</head>
<body>
    <div class="wrap js-check-wrap">
        <ul class="nav nav-tabs">
            <li class="active"><a href="<?php echo U('Portal/AdminOrder/index');?>">返回列表</a></li>
        </ul>
        <form class="well form-search" method="get" action="/index.php/Portal/AdminOrder/index2">
            投注号码:
            <input type="text" name="betnumber" style="width: 200px;" value="<?php echo ($get["betnumber"]); ?>" placeholder="投注号码">
            <input type="hidden" name="uid" value="<?php echo ($_GET['uid']); ?>" />
            <input type="hidden" name="BetInfoID" value="<?php echo ($_GET['BetInfoID']); ?>" />
            <input type="submit" class="btn btn-primary" value="搜索" />
        </form>
        <form class="js-ajax-form" action="" method="post">
            <table class="table table-hover table-bordered table-list">
                <thead>
                <tr>    
                <th width="50">ID</th>
                <th>用户id</th>
                <th>用户名</th>
                <th>玩法</th>
                <th>投注金额</th>
                <th>赔率</th>
                <th>投注号码</th>
                <th>开奖号码</th>

                <th>奖金状态</th>
                <th>
                    修改: 
                    <a href="<?php echo U('Portal/AdminOrder/xgzd',array('BetInfoID'=>$BetInfoID,'uid'=>$uid,'batch'=>1));?>">普通批量</a>
                    <a href="<?php echo U('Portal/AdminOrder/xgzd2',array('BetInfoID'=>$BetInfoID,'uid'=>$uid));?>">快选批量
                        <?php if ($bz_info['is_editable'] !== true) { echo '(<span style="color:#f03;">不支持</span>)'; } else { echo '(<span>支持</span>)'; } ?>
                    </a>
                </th>
                </tr>
                </thead>

                <?php if(is_array($posts)): foreach($posts as $key=>$vo): ?><tr>
                    <?php $zt='等待中奖'; if($vo['sftm']==1){ $zt='已经退码'; } if($vo['zt']==1){ if($vo['winloss']>0){ $zt='奖金<span style="color:#e4393c">'.$vo['winloss'].'</span>'; } else{ $zt='未中奖'; } } else{ $vo['lotteryno']='--'; } $uid=I('get.uid'); ?>
                    <td><b><?php echo ($vo["id"]); ?></b></td>
                    <td><?php echo ($bet["uid"]); ?></td>
                    <td><?php echo (user_login($bet["uid"])); ?></td>
                    <td><?php echo (played($vo["playedid"])); ?></td>
                    <td><?php echo ($vo[betamount]); ?></td>
                    <td><?php echo ($vo[odds]); ?></td>
                    <td><?php echo ($vo[betnumber]); ?></td>
                    <td><?php echo ($bet[lotteryno]); ?></td>
                    <td><?php echo ($zt); ?></td>

                    <td><a href="<?php echo U('Portal/AdminOrder/xgzd',array('BetInfoID'=>$vo[betinfoid],id=>$vo['id'],'uid'=>$uid));?>">修改注单</a></td>
                    </tr><?php endforeach; endif; ?>
               
            </table>
            <div class="pagination"><?php echo ($page); ?></div>
        </form>
    </div>
    <script src="/public/js/common.js"></script>
</body>
</html>