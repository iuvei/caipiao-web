<?php if (!defined('THINK_PATH')) exit();?>
<style>


</style>


<div class="table-out" id="ROLE-TPL">
    <table class="tablecommon" width="100%" cellspacing="0" cellpadding="0" border="0">
        <tr class="title">
            <td>&#12288;</td>
        </tr>
        <tr>
            <td style="font-size: 14px; padding-left: 100px;">
                <br><br><h3 align=center><span class="style2">境外圣地彩票游戏规则</span></h3>
                <p>
                    <b>第一章　总　则</b><br><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第一条</b>　根据美国圣地彩公平、公正开奖号码，制定本游戏规则。<br><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第二条</b>　本站彩票实行自愿购买，量力而行；凡下注者即被视为同意并遵守本规则。          <b></b><br>
                    <b>
                        <br>
                        第二章　游戏方法
                    </b><br><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第三条</b>　
                    <label> "五位数"的每注彩票由00000-99999中的任意5位自然数排列而成。</label>
                   <span class="style2"><strong>本站取前面4位做为游戏规则！</strong></span><br>
                    <span class="text-03"></span><br>
                    <br>
                    <b>  <span class="style2">假设下列为开奖结果：</span></b>
                </p>
                <br />
                <table class=b_tab cellspacing=1 cellpadding=0 width="50%" border=0>
                    <tbody>

                        <tr class=b_tline_bk>
                            <td width="12%">仟</td>
                            <td width="12%">佰</td>
                            <td width="15%">拾</td>
                            <td width="16%">个</td>
                            <td width="14%">球5</td>
                           

                        </tr>
                        <tr class=b_cen>
                            <td><b><font color=#cc0000>1</font></b></td>
                            <td><b><font color=#cc0000>2</font></b></td>
                            <td><b><font color=#cc0000>3</font></b></td>
                            <td><b><font color=#cc0000>4</font></b></td>
                            <td><b><font color=#cc0000>5</font></b></td>
                           
                        </tr>
                       
                    </tbody>

                </table><br />
                <p class="style3">依照开奖结果，中奖范例如下：</p><br />
                <p class="style3">四字定中奖：</p><br />
                <p class="style1">1234</p><br />
                <p><span class="style3">二字定中奖：</span></p><br />
                <p><span class="style1">12xx； 1x3x； 1xx4； x23x； x2x4； xx34 </span></p><br />
                <p><span class="style3">三字定中奖：</span></p><br />
                <p><span class="style1">123x； 12x4； 1x34； x234 </span></p><br />
                <p><span class="style3"><strong>二字现中奖：</strong></span></p><br />
                <p><span class="style2"><strong>12；13；14；23；24；34</strong></span></p><br />
                <p><span class="style3"><strong>三字现中奖：</strong></span></p><br />
                <p><span class="style2"><strong>123；124；134；234</strong></span></p><br />
                <p><span class="style3"><strong>四字现中奖：</strong></span></p><br />
                <p><span class="style2"><strong>1234 现；</strong></span></p><br />

                <b>第三章　开奖及公告</b><br>
                <br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第四条</b>
                每10分钟一期，全天90期，通过境外开奖平台发布更新。
                <br>
                <br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第五条</b>　每期开奖后，以境外彩票平台公布的开奖号码为准。<br>
                <br>

                <b>第四章　附　则</b><br>
                <br>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>第六条</b>　本游戏规则最终解释权归本公司。</p><br />
            </td>
        </tr>
    </table>
</div>