<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<link href="/public/simpleboot/themes/<?php echo C('SP_ADMIN_STYLE');?>/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
	<script type="text/javascript">
	//全局变量
	var GV = {
	    ROOT: "/",
	    WEB_ROOT: "/",
	    JS_ROOT: "public/js/",
	    APP:'<?php echo (MODULE_NAME); ?>'/*当前应用名*/
	};
	</script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
    	$(function(){
    		$("[data-toggle='tooltip']").tooltip();
    	});
    </script>
<?php if(APP_DEBUG): ?><style>
		#think_page_trace_open{
			z-index:9999;
		}
	</style><?php endif; ?>
</head>
<body>
	<div class="wrap js-check-wrap">
		<ul class="nav nav-tabs">
			<li><a href="<?php echo U('Portal/AdminSystem/lottery_typeset');?>">所有彩种</a></li>
            <li class="active"><a href="<?php echo U('Portal/AdminSystem/add_lottery_typeset');?>" >添加彩种</a></li>
		</ul>
		<form class="form-horizontal js-ajax-form" action="<?php echo U('AdminSystem/add_lottery_typesetpost');?>" method="post">
			<fieldset>
                <div class="control-group" >
					<label class="control-label">彩种名称</label>
					<div class="controls" >
                        <input type="text" style="color: red" name="title"value="<?php echo ($post["title"]); ?>" required>
					</div>
				</div>
				<div class="control-group" >
					<label class="control-label">彩种简称(字母)</label>
					<div class="controls" >
                        <input type="text" style="color: red" name="name" value="<?php echo ($post["name"]); ?>" required>
					</div>
				</div>
				<div class="control-group" >
					<label class="control-label">彩种简介</label>
					<div class="controls" >
                        <textarea type="text" name="info" required><?php echo ($post["info"]); ?></textarea>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label">停止投注时间间隔</label>
					<div class="controls" >
                        <input type="number" style="color: red" name="data_ftime"  value="<?php echo ($post["data_ftime"]); ?>" required>
					</div>
				</div>
			
				<div class="control-group">
					<label class="control-label">开关/关闭</label>
					<div class="controls">
						<?php $active_true_checked=($post['enable']==0)?"checked":""; ?>
						<label class="radio inline" for="yes">
							<input type="radio" name="enable" value="0" <?php echo ($active_true_checked); ?> id="yes"/>关
						</label>
						<?php $active_false_checked=($post['enable']==1)?"checked":""; ?>
						<label class="radio inline" for="no">
							<input type="radio" name="enable" value="1" id="no"<?php echo ($active_false_checked); ?>>开
						</label>
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">彩种类别</label>
					<div class="controls">
						<?php $active_checked=($post['type']==1)?"checked":""; ?>
						<label class="radio inline" for="xz1">
							<input type="radio" name="type" value="1" <?php echo ($active_checked); ?> id="xz1"/>快3
						</label>
						<?php $active_checked=($post['type']==2)?"checked":""; ?>
						<label class="radio inline" for="xz2">
							<input type="radio" name="type" value="2" id="xz2" <?php echo ($active_checked); ?>>时时彩
						</label>
						<?php $active_checked=($post['type']==3)?"checked":""; ?>
						<label class="radio inline" for="xz3">
							<input type="radio" name="type" value="3" id="xz3" <?php echo ($active_checked); ?>>11选5
						</label>
					</div>
				</div>                            
                      
                <div class="control-group">
                    <label class="control-label">排序</label>
                    <div class="controls">
                        <input type="number" name="sort" value="<?php echo ($post["sort"]); ?>" required>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">期数</label>
                    <div class="controls">
                        <input type="number" name="num" value="<?php echo ($post["num"]); ?>" required>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">期号函数</label>
                    <div class="controls">
                        <select name="onGetNoed" required>
               				<option value="timelx">时间类</option>
               				<option value="addlx">增长类</option>
               			</select>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">期号参数</label>
                    <div class="controls">
                        <input type="text" name="oncs" value="<?php echo ($post["oncs"]); ?>" required>
                    </div>
                </div>
                           
			</fieldset>
			<div class="form-actions">
				<input type="hidden" name="id" value="<?php echo ($post["id"]); ?>"/>
				<button type="submit" class="btn btn-primary"><?php echo L('SAVE');?></button>
				<a class="btn" href="javascript:history.back(-1);"><?php echo L('BACK');?></a>
			</div>
		</form>
	</div>
	<script src="/public/js/common.js"></script>
</body>
</html>