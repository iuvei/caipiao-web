<?php if (!defined('THINK_PATH')) exit();?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0046)http://fw5.b789b.com/index.php?action=leveladd -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <title></title>
     
    <style type="text/css">
        .lezhu99 {
            color: gray;
        }

    </style>
   
</head>
<body >
    <div id="append_parent"></div>
    <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
        <tbody>
            <tr>
                <td>
                    
                    <style media="print">
                        .Noprint {
                            display: none;
                        }
                    </style> <table class="Noprint" width="100%" border="0" cellpadding="0" cellspacing="0">                        
                    </table>
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" data-bind="visible:!IsCompanySettingDirectMember">
                        <tbody>
                            
                            <tr class="header">
                                <td style=" border-top: 1px solid #525c3d;">
                                    <div style="float: left; margin-left: 0px; padding-top: 0px;">
                                        <a href="#">信息提示</a>
                                    </div><div style="float:right; margin-right:4px; padding-bottom:9px">
                                        
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                        <tbody>
                             
                            <tr>
                                <td height="50px">
                                    <ul>
                                        <li>
                                            <span data-bind="click:back" style="cursor:pointer">
                                                <label style="color:blue;cursor:pointer" id="HandlersAccountMember" />
                                            </span>
                                            &nbsp;&nbsp;
                                            可用额度：    <label data-bind="text:ParentDefaultCredit"></label>  &nbsp;&nbsp;&nbsp;&nbsp;
                                            
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        </tbody>
                    </table> 
                    <div class="add-top">&#12288;                        
                        <span data-bind="text:LoginNameMember" />
                        >>
                        <span data-bind="text:isEdit?'编辑':'新增'"/> 
                        会员
                        <span id="GradeName" />
                    </div>
                    <form method="post" action="/Member/AddMember" data-bind="submit:sub">

                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
                            <tbody>

                                <tr>
                                    <td class="altbg1">账　　号:</td>
                                    <td align="right" class="altbg2">
                                        <input type="text" maxlength="12" id="accountStyle" data-bind="textinput:account,visible:!isEdit" placeholder="长度为3-12位" />
                                        <input class="button" type="button" name="chenck" value="账号检查" data-bind="click:GetCheckRepeatAccount,visible:!isEdit" />
                                        <label data-bind="text:account,visible:isEdit"></label>
                                        
                                        <font style="font-size:14px;" data-bind="visible:!isEdit" color="red">(只能是字母和数字，并字母开头，长度为3-12位)</font>
                                    </td>
                                </tr>
                                <tr data-bind="visible:!isEdit">
                                    <td class="altbg1">密　　码:</td>
                                    <td align="right" class="altbg2">
                                        <input type="password" data-bind="textinput:password" placeholder="长度为8-15位" maxlength="15" />
                                        <font style="font-size:14px;" color="red">  (密码的长度必须在8-15位之间,并且包含字母和数字)</font>
                                    </td>
                                </tr>
                                <tr data-bind="visible:!isEdit">
                                    <td class="altbg1">确认密码:</td>
                                    <td align="right" class="altbg2">
                                        <input type="password" data-bind="textinput:repassword" placeholder="长度为8-15位" maxlength="15" />
                                        <font style="font-size:14px;" color="red">  (确认密码与密码必须保持一致)</font>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="altbg1">昵　　称:</td>
                                    <td align="right" class="altbg2"><input type="text" data-bind="textinput:nickname" placeholder="长度为1-20位" /></td>
                                </tr>
                                <tr>
                                    <td class="altbg1">信用额度:</td>
                                    <td align="right" class="altbg2">
                                        
                                        <input type="text" data-bind="textinput:DefaultCredit" maxlength="8"   placeholder="长度为1-8位" />
                                          <label data-bind="text:DefaultCreditChinese"></label>
                                        <label style="color:red;">提示：信用额度不能超过上级信用额度</label>
                                    </td>
                                </tr>
                                <!--tr data-bind="visible:IsDLUpdateRatio==1"-->
                                <tr>
                                    <td class="altbg1">拦货占成上限</td>
                                    
                                    <td align="right" class="altbg2">
                                        <label id="RationLable"></label>
                                        
                                        <select class="form-control" id="ratioLen" data-bind="options:rationlist,optionsText:'RatioName',optionsValue:'Ratio',value:CurrentLevelRatio"></select>
                                        
                                        <br />
                                        （设置占成，需要在“设置”中添加<label style="color:red;"> 拦货金额</label>才生效）。<label style="color:red;">提示</label>:如果庄家先吃满,则不以所设成数来分配,以实际分配到拦货中金额为准。
                                    </td>
                                    

                                    
                                     
                                </tr>
                                <tr>
                                    <td class="altbg1">状　　态:</td>
                                    <td align="right" class="altbg2">

                                        <select class="form-control" data-bind="options:statusList,optionsText:'name',optionsValue:'value',value:status"></select>
                                    </td>
                                </tr>
                                 
                                <tr>
                                    <td class="altbg1">备注:</td>
                                    <td align="right" class="altbg2">
                                        <textarea class="form-control" rows="3" maxlength="255" data-bind="textinput:remark"></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table><br />
                        <center>
                            <input class="button" type="submit" name="addsubmit" value="提 交" />
                            &nbsp; &nbsp; &nbsp; &nbsp;
                            <input class="button" type="button" name="button" value="返 回" data-bind="click:back" />
                        </center>
                    </form>
                </td>
            </tr>
        </tbody>
    </table>
    
</body>
</html>