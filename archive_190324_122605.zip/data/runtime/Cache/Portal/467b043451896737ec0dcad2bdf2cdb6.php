<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<link href="/public/simpleboot/themes/<?php echo C('SP_ADMIN_STYLE');?>/theme.min.css" rel="stylesheet">
    <link href="/public/simpleboot/css/simplebootadmin.css" rel="stylesheet">
    <link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
    <link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
	<![endif]-->
	<script type="text/javascript">
	//全局变量
	var GV = {
	    ROOT: "/",
	    WEB_ROOT: "/",
	    JS_ROOT: "public/js/",
	    APP:'<?php echo (MODULE_NAME); ?>'/*当前应用名*/
	};
	</script>
    <script src="/public/js/jquery.js"></script>
    <script src="/public/js/wind.js"></script>
    <script src="/public/simpleboot/bootstrap/js/bootstrap.min.js"></script>
    <script>
    	$(function(){
    		$("[data-toggle='tooltip']").tooltip();
    	});
    </script>
<?php if(APP_DEBUG): ?><style>
		#think_page_trace_open{
			z-index:9999;
		}
	</style><?php endif; ?>
</head>
<body>
	<div class="wrap js-check-wrap">
		<ul class="nav nav-tabs">
			<li><a href="<?php echo U('AdminOrder/kaijiang');?>" >开奖列表</a></li>
            <li class="active"><a href="javascript:;" target="_self">添加开奖号码</a></li>
		</ul>
		<form class="form-horizontal" action="<?php echo U('Portal/AdminOrder/add_kaijiang');?>" method="post">
			<fieldset>
				<div class="control-group" >
					<label class="control-label">彩种</label>
					<div class="controls" >
						<select name="post[type]" style="width: 120px;">
						<option value="0">选择彩种</option>
						<?php if(is_array($typelist)): foreach($typelist as $key=>$one): ?><option value="<?php echo ($one["id"]); ?>" <?php if($one[id] == $_GET[type]): ?>selected<?php endif; ?>><?php echo ($one["title"]); ?></option><?php endforeach; endif; ?>          
						</select>
					</div>
				</div>
                <div class="control-group" >
					<label class="control-label">开奖时间</label>
					<div class="controls" >
                        <input type="text" name="post[time]" class="js-datetime" value="<?php echo ($_GET[kjtime]); ?>" style="width: 120px;" autocomplete="off" required>
					</div>
				</div>
				<div class="control-group" >
					<label class="control-label">期数</label>
					<div class="controls" >
                        <input type="number" style="color: red" name="post[qs]"value="<?php echo ($_GET[number]); ?>" required>
					</div>
				</div>
				<div class="control-group" >
					<label class="control-label">开奖号码</label>
					<div class="controls" >
                        <input type="text" onchange="zmmyzbh($(this))" id="data" style="color: red" name="post[data]" value="" required >用,隔开
					</div>
				</div>           
			</fieldset>
			<div class="form-actions">
				<!-- <input type="hidden" name="id" value="<?php echo ($post["id"]); ?>"/> -->
				<input type="submit" class="btn btn-primary">
				<a class="btn" href="javascript:history.back(-1);"><?php echo L('BACK');?></a>
			</div>
		</form>
	</div>
	<script src="/public/js/common.js"></script>
	<script>
	function zmmyzbh(obj){
			if(/[^0-9\,]{1}$/i.test($('#data').val())){
				alert('开奖号码格式错误');
				$('#data').val('');
			}
	}
	</script>
</body>
</html>